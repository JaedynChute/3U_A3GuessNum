# 3U_A3GuessNum


Program Description:
Make a guess the number game. The computer generates a random number between 1 and 100 and gives the player up to 5 chances to guess it to win.

1. Challenge1: Display a hint to the user.
 - Freezing—more than 50 away.
 - Cold—more than 25 away.
 - Warm—more than 10 away.
 - Hot—more than 5 away.

1. Challenge2: Change the range from 1-100 and display the new range to the user to guess from.

1. Challenge3: Ask the user if they want to play again. Without having to click on “run” again.

1. Challenge4: Be creative! What else can you add to this to make it better? Tell me in your submission what functionality you added.

Check assignment on classroom for checklist of skills and more hints.
