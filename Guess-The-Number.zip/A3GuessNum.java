import java.util.*;

public class A3GuessNum { 
 
  public static void main(String[] args){

    Scanner input = new Scanner(System.in); 
    Random numGenerator = new Random(); 
    int numberOfGuesses = 0; 
    int state = 1;
    int answer = numGenerator.nextInt(101); 
    final int maximumGuesses = 5; 
    boolean correctGuess = false; 
  

      System.out.println("Random Number Generator"); 
 
 while (!correctGuess || numberOfGuesses < 5) {
       
       if (state == 1) {
          System.out.print("Enter a number from 0-100: ");
          int guess = input.nextInt();  
          numberOfGuesses++;

       
      if (guess == answer) {
        correctGuess = true;
        System.out.println("\nYou win!!");
        System.out.println("The correct number to guess was " + answer + "!");
        if (numberOfGuesses == 1) {
          System.out.println(" You guessed the number !");
        } else if (numberOfGuesses == 2) {
          System.out.println("Two Guesses");
        } else if (numberOfGuesses == 3) {
          System.out.println("Three Guesses");
        } else if (numberOfGuesses == 4) {
          System.out.println("Four Guesses");
        } else if (numberOfGuesses == 5) {
          System.out.println("Five guesses");
        } 
        System.out.println("\nwant to play again?");
        state = 0;
        }

        
        else if (guess < answer) {
          System.out.println("\ntoo low!");
          }
        
       
        else if (guess > answer) {
          System.out.println("\ntoo high! ");
          }

        
        if (guess < 25 && answer < 25 && guess != answer) {
          System.out.print("number is between 0 and 25!\n");
        } else if (guess >= 25 && guess <= 50 && answer >= 25 && answer <= 50 && guess != answer) {
              System.out.print("answer is between 25 and 50!\n");
        } else if (guess >= 50 && guess <= 75 && answer >= 50 && answer <= 75 && guess != answer) {
              System.out.println(" answer is between 50 and 75!\n");
        } else if (guess > 75 && answer > 75 && guess != answer) {
              System.out.println("number is between 75 and 100!\n");
        }